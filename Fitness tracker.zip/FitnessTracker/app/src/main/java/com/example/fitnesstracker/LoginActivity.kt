package com.example.fitnesstracker

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()
        val loginButton: Button = findViewById(R.id.login_button)
        val emailText: EditText = findViewById(R.id.email_edittext)
        val passwordText: EditText = findViewById(R.id.password_edittext)
        val registerText: TextView = findViewById(R.id.register_textview)
        val forgotPasswordTextView: TextView = findViewById(R.id.forgot_password_textview)

        loginButton.setOnClickListener {
            val email = emailText.text.toString()
            val password = passwordText.text.toString()

            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        Log.d("LoginActivity", "signInWithEmail:success")
                        val user = auth.currentUser
                        startActivity(Intent(this, DashboardActivity::class.java))
                    } else {
                        Log.w("LoginActivity", "signInWithEmail:failure", task.exception)
                        Toast.makeText(baseContext, "Authentication failed.",
                            Toast.LENGTH_SHORT).show()
                    }
                }
        }

        registerText.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }


        forgotPasswordTextView.setOnClickListener {
            val dialog = AlertDialog.Builder(this)
            dialog.setTitle("Forgot Password")
            dialog.setMessage("Enter your email address to reset your password")

            val emailEditText = EditText(this)
            emailEditText.hint = "Email"
            emailEditText.inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS

            dialog.setView(emailEditText)

            dialog.setPositiveButton("Send Reset Email") { _, _ ->
                val email = emailEditText.text.toString()
                if (email.isNotEmpty()) {
                    auth.sendPasswordResetEmail(email)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                Toast.makeText(this, "Password reset email sent!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this, "Error sending password reset email!", Toast.LENGTH_SHORT).show()
                            }
                        }
                } else {
                    Toast.makeText(this, "Please enter your email address!", Toast.LENGTH_SHORT).show()
                }
            }

            dialog.setNegativeButton("Cancel") { _, _ ->
                // Cancel the dialog
            }

            dialog.show()
        }


    }
}